const Navbar = () => {
    return (
        <div className="navbar">
            
        </div>
    )
}

export default Navbar;