// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "@firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDpOjBGwFRV-X-7msCCdWXufYtsEdJNmiA",
  authDomain: "mdcloud-e7d6b.firebaseapp.com",
  projectId: "mdcloud-e7d6b",
  storageBucket: "mdcloud-e7d6b.appspot.com",
  messagingSenderId: "648098233502",
  appId: "1:648098233502:web:bba1dfbfdf19f6706acf8f",
  measurementId: "G-BKVPMGP3E8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

 export const db = getFirestore(app)