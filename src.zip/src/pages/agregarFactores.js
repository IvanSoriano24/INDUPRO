import React, {useState, useEffect} from "react"
import {useNavigate} from "react-router-dom"
import { collection, addDoc, query, orderBy, limit,getDocs } from "firebase/firestore"
import { db } from "../firebaseConfig/firebase"
import {TabContent, TabPane, Nav, NavItem, NavLink  } from "reactstrap"
import { FaCircleQuestion } from "react-icons/fa6";
import { Link } from "react-router-dom";


const AgregarFactores  = () => {
    const [cve_far, setCve_far] = useState("");
    const [nombre, setNombre] = useState("");
    const [costoFijo, setCostoFijo] = useState();
    const [factoraje, setFactoraje] = useState();
    const [fianzas, setFianzas] = useState();
    const [utilidad, setUtilidad] = useState();
    const factorUtilidad = 1.0 + (parseFloat(parseInt(costoFijo/100)) + parseFloat(parseInt(factoraje)/100) + parseFloat(parseInt(fianzas)/100) + parseFloat(parseInt(utilidad)/100));
    const navigate = useNavigate()
    const factoresCollection = collection(db,"FACTORES")

    useEffect(() => {
        // Obtener el último valor de CVE_PEPR
        const obtenerUltimoCvePepr = async () => {
            const q = query(collection(db, "FACTORES"), orderBy("cve_far", "desc"), limit(1));
            const result = await getDocs(q);

            if (result.docs.length > 0) {
                const ultimoCvePepr = result.docs[0].data().cve_far;
                // Incrementar el valor y establecerlo en el estado
                const nuevoCvePepr = (parseInt(ultimoCvePepr) + 1).toString().padStart(2, "0");
                setCve_far(nuevoCvePepr);
            } else {
                // Si no hay registros, establecer el primer valor
                setCve_far("01");
            }
        };
        obtenerUltimoCvePepr();
    }, []);

    const addFactores = async(e) =>{
        e.preventDefault()
        await addDoc(factoresCollection, {
            cve_far: cve_far, 
            nombre: nombre, 
            costoFijo: costoFijo, 
            factoraje: factoraje,
            fianzas: fianzas,
            utilidad: utilidad,
            factorUtilidad: factorUtilidad
            } );
            navigate("/factores")
    };
    
    return (
        <div className="container">
            <div className="row">
                <div className="col">
                    <h1>AGREGAR INSUMOS POR FACTOR</h1>
                    <form onSubmit={addFactores}>
                        <div className="row">
                            <div className="col-md-3">
                                <div className="mb-3">
                                    <label className="form-label">NOMBRE DE INSUMO</label>
                                    <input
                                    value={nombre}
                                    onChange={(e) => setNombre(e.target.value)}
                                    type="text"
                                    className="form-control"            
                                    />
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div className="mb-3">
                                    <label className="form-label">COSTO FIJO</label>
                                    <input
                                    value={costoFijo}
                                    onChange={(e) => setCostoFijo(e.target.value)}
                                    type="number"
                                    
                                    className="form-control"            
                                    />
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div className="mb-3">
                                    <label className="form-label">FACTORAJE</label>
                                    <input
                                    value={factoraje}
                                    onChange={(e) => setFactoraje(e.target.value)}
                                    type="number"
                                    
                                    className="form-control"            
                                    />
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div className="mb-3">
                                    <label className="form-label">FIANZAS</label>
                                    <input
                                    value={fianzas}
                                    onChange={(e) => setFianzas(e.target.value)}
                                    type="number"
                                    
                                    className="form-control"            
                                    />
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div className="mb-3">
                                    <label className="form-label">UTILIDAD</label>
                                    <input
                                    value={utilidad}
                                    onChange={(e) => setUtilidad(e.target.value)}
                                    type="number"
                                    
                                    className="form-control"            
                                    />
                                </div>
                            </div>
                            <div className="buttons-container">
                                <button type="submit" className="btn btn-primary">AGREGAR</button>
                                <Link to="/clientes"><button className="btn btn-danger" >Regresar</button></Link>
                             </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default AgregarFactores