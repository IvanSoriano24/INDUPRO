const precotizacion = () => {
    return (
        <div>
            <p>precotizacion</p>
        </div>
    )
}

export default precotizacion