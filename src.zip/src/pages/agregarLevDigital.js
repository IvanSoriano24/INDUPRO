import React, {useState, useEffect} from "react"
import {useNavigate} from "react-router-dom"
import { collection, addDoc, query, orderBy, limit,getDocs } from "firebase/firestore"
import { db } from "../firebaseConfig/firebase"
import {TabContent, TabPane, Nav, NavItem, NavLink  } from "reactstrap"
import { FaCircleQuestion } from "react-icons/fa6";
import { Link } from "react-router-dom";

const AgregarLevDigital = () => {
    /* ---------------------ENCABEZADO DE DOCUMENTO ------------------------------------- */
    const [cve_levDig, setCve_levDig] = useState("");
    const [cve_clie, setCve_clie] = useState("");
    const [fechaElaboracion, setFechaElaboracion] = useState("");
    const [fechaInicio, setFechaInicio] = useState("");
    const [fechaFin, setFechaFin] = useState("");
    const navigate = useNavigate()

    const EncabezadoCollection = collection(db, "LEVDIGITA")

  return (
    <div className="container">
        <div className="row">
            <div className="col">
                <h1>Levantamiento digital</h1>
                <form>
                    <div className="row">
                        <div className="col-md-3">
                            <div className="mb-3">
                                <label className="form-label">NOMBRE DE INSUMO</label>
                                <select class="form-control form-control-lg">
                                    <option>Large select</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
  );
};

export default AgregarLevDigital;
