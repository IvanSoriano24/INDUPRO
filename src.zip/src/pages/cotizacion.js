const cotizacion = () => {
    return (
        <div>
            <p>cotizacion</p>
        </div>
    )
}

export default cotizacion