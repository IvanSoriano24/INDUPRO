import React, { useState, useEffect } from "react";
import { collection, getDocs } from "@firebase/firestore";
import { db } from "../firebaseConfig/firebase";
import { Link } from "react-router-dom";
import { FaPencilAlt, FaEye  } from "react-icons/fa";
import { RiFileUserFill } from "react-icons/ri";

const Contactos = () => {
    const [contactos, setContactos] = useState([]);

    const getContactos = async () => {
        const data = await getDocs(collection(db, "CONTACTOS")); // Cambiado a "CLIENTES"
        const contactosList = data.docs.map(doc => ({ ...doc.data(), id: doc.id }));
        setContactos(contactosList);
    }
    
    /*const deleteCliente = async (id) => {
       const ClienteDoc =  doc(db, "CLIENTES", id)
       await deleteCliente(ClienteDoc)
       getClientes()
    }*/

    useEffect(() => {
        getContactos(); // Cambiado a "getClientes"
    }, []);
    //console.log(clientes);
    return (
        <div className="container">
            <div className="row">
                <div className="col">
                    <div className="d-grid gap-2">
                        <Link to="/" className="btn btn-secondary mt-2 mb-2">Agregar nuevo contacto</Link>
                    </div>
                    <table className="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>NOMBRE</th>
                                <th>TELEFONO</th>
                                <th>CORREO</th>
                                <th>DETALLE</th>
                                <th>EDITAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            {contactos.map((contactos) => (
                                <tr>
                                    <td>{contactos.nombre}</td>
                                    <td>{contactos.telefono}</td>
                                    <td>{contactos.correo}</td>
                                    <td><Link to={`/visualizarContacto/${contactos.id}`} className="btn btn-light"><FaEye /></Link></td>
                                    <td><Link to={`/editarContacto/${contactos.id}`} className="btn btn-light"><FaPencilAlt /></Link></td>
                                </tr>
                            ) )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default Contactos