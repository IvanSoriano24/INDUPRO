const revTecnicoFinanciero = () => {
    return (
        <div>
            <p>Revisión técnico financiero</p>
        </div>
    )
}

export default revTecnicoFinanciero