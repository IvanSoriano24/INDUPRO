import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { collection, addDoc, updateDoc, doc, getDoc, endAt, query, orderBy, limit,getDocs  } from "firebase/firestore";
import { db } from "../firebaseConfig/firebase";
import { FaCircleQuestion } from "react-icons/fa6";
import { Link } from "react-router-dom";

const AgregarPersonal  = () => {
    const [cvePepr, setCvePepr] = useState("");
    const [factor, setFactor] = useState();
    const [personal, setPersonal] = useState("");
    const [salarioDiario, setSalarioDiario] = useState();
    const valorHombre = salarioDiario * factor;
    const navigate = useNavigate();
    useEffect(() => {
        // Obtener el último valor de CVE_PEPR
        const obtenerUltimoCvePepr = async () => {
            const q = query(collection(db, "PERSONAL"), orderBy("CVE_PEPR", "desc"), limit(1));
            const result = await getDocs(q);

            if (result.docs.length > 0) {
                const ultimoCvePepr = result.docs[0].data().CVE_PEPR;
                // Incrementar el valor y establecerlo en el estado
                const nuevoCvePepr = (parseInt(ultimoCvePepr) + 1).toString().padStart(2, "0");
                setCvePepr(nuevoCvePepr);
            } else {
                // Si no hay registros, establecer el primer valor
                setCvePepr("01");
            }
        };

        obtenerUltimoCvePepr();
    }, []);

    const personalCollection = collection(db,"PERSONAL")

    const addPersonal = async(e) => {
        e.preventDefault()
        await addDoc(personalCollection, { CVE_PEPR: cvePepr,  personal: personal, salarioDiario: salarioDiario, factor: factor, valorHombre: valorHombre})
        navigate("/personalProyectos");
    }
    return (
        <div className="container">
            <div className="row">
                <div className="col">
                <h1>Agregar un contato</h1>
                        <form onSubmit={addPersonal}>
                            <div className="row">
                            <div className="col-md-3">
                                    <div className="mb-3">
                                        <label className="form-label">NOMBRE DE PERSONAL</label>
                                        <input
                                            value={personal}
                                            onChange={(e) => setPersonal(e.target.value)}
                                            type="text"
                                            className="form-control"
                                            
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="mb-3">
                                        <label className="form-label">SALARIO DIARIO</label>
                                        <input
                                            value={salarioDiario}
                                            onChange={(e) => setSalarioDiario(e.target.value)}
                                            type="number"
                                            className="form-control"
                                            
                                        />
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className="mb-3">
                                        <label className="form-label">FACTOR</label>
                                        <input
                                            value={factor}
                                            onChange={(e) => setFactor(e.target.value)}
                                            type="number"
                                            className="form-control"
                                            
                                        />
                                    </div>
                                </div>
                                <div className="buttons-container">
                                <button type="submit" className="btn btn-primary">AGREGAR PERSONAL</button>
                                <Link to="/clientes"><button className="btn btn-danger" >Regresar</button></Link>
                             </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
    )
}

export default AgregarPersonal