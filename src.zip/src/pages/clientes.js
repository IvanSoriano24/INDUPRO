import React, { useState, useEffect } from "react";
import { collection, getDocs } from "@firebase/firestore";
import { db } from "../firebaseConfig/firebase";
import { Link } from "react-router-dom";
import { FaPencilAlt, FaEye  } from "react-icons/fa";
import { RiFileUserFill } from "react-icons/ri";

const Clientes = () => {
    const [clientes, setClientes] = useState([]);

    const getClientes = async () => {
        const data = await getDocs(collection(db, "CLIENTES")); // Cambiado a "CLIENTES"
        const clienteList = data.docs.map(doc => ({ ...doc.data(), id: doc.id }));
        setClientes(clienteList);
    }
    
    /*const deleteCliente = async (id) => {
       const ClienteDoc =  doc(db, "CLIENTES", id)
       await deleteCliente(ClienteDoc)
       getClientes()
    }*/

    useEffect(() => {
        getClientes(); // Cambiado a "getClientes"
    }, []);

    //console.log(clientes);

    return (
        <div className="container">
            <div className="row">
                <div className="col">
                    <div className="d-grid gap-2">
                        <Link to="/agregarCliente" className="btn btn-secondary mt-2 mb-2">Agregar nuevo cliente</Link>
                    </div>
                    <table className="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>CLAVE</th>
                                <th>RAZÓN SOCIAL</th>
                                <th>CALLE</th>
                                <th>CP</th>
                                <th>COLONIA</th>
                                <th>ESTADO</th>
                                <th>MUNICIPIO</th>
                                <th>ESTATUS</th>
                                <th>DETALLE</th>
                                <th>EDITAR</th>
                                <th>AGREGAR CONTACTO</th>
                            </tr>
                        </thead>
                        <tbody>
                            {clientes.map((cliente) => (
                                <tr>
                                    <td>{cliente.cve_clie}</td>
                                    <td>{cliente.razonSocial}</td>
                                    <td>{cliente.calle}</td>
                                    <td>{cliente.codigoPostal}</td>
                                    <td>{cliente.colonia}</td>
                                    <td>{cliente.estado}</td>
                                    <td>{cliente.municipio}</td>
                                    <td>{cliente.estatus}</td>
                                    <td><Link to={`/visualizarCliente/${cliente.id}`} className="btn btn-light"><FaEye /></Link></td>
                                    <td><Link to={`/editarCliente/${cliente.id}`} className="btn btn-light"><FaPencilAlt /></Link></td>
                                    <td><Link to={`/agregarContacto/${cliente.id}`} className="btn btn-light"><RiFileUserFill /></Link></td>
                                </tr>
                            ) )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      );
      
    
}

export default Clientes;
