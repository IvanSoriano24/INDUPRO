const TipoInsumos = () => {
    return (
        <div>
            <p>cotizacion</p>
        </div>
    )
}

export default TipoInsumos