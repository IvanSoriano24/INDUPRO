import React, { useState, useEffect } from "react";
import { collection, getDocs } from "@firebase/firestore";
import { db } from "../firebaseConfig/firebase";
import { Link } from "react-router-dom";
import { FaPencilAlt, FaEye  } from "react-icons/fa";
import { RiFileUserFill } from "react-icons/ri";

const PersonalProyectos  = () => {
    const [personal, setPersonal] = useState([]);

    const getPersonal = async () => {
        const data = await getDocs(collection(db, "PERSONAL"));
        const personalList = data.docs.map(doc => ({ ...doc.data(), id: doc.id }));
        setPersonal(personalList);
    }

    /* 
    // No olvides cambiar las referencias a la colección y la función deleteCliente si las utilizas
    const deletePersonal = async (id) => {
        const personalDoc = doc(db, "PERSONAL", id);
        await deleteDoc(personalDoc);
        getPersonal();
    }
    */

    useEffect(() => {
        getPersonal();
}, []);


    return (
        <div className="container">
            <div className="row">
                <div className="col">
                    <div className="d-grid gap-2">
                        <Link to="/agregarPersonal" className="btn btn-secondary mt-2 mb-2">Agregar personal</Link>
                    </div>
                    <table className="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>CLAVE</th>
                                <th>PERSONAL</th>
                                <th>SALARIO DIARIO</th>
                                <th>VALOR HOMBRE</th>
                                <th>DETALLE</th>
                                <th>EDITAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            {personal.map((personal) => (
                                <tr>
                                    <td>{personal.CVE_PEPR}</td>
                                    <td>{personal.personal}</td>
                                    <td>{personal.salarioDiario}</td>
                                    <td>{personal.valorHombre}</td>
                                    <td><Link to={`/visualizarPersonal/${personal.id}`} className="btn btn-light"><FaEye /></Link></td>
                                    <td><Link to={`/editarPersonalProyecto/${personal.id}`} className="btn btn-light"><FaPencilAlt /></Link></td>
                                </tr>
                            ) )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default PersonalProyectos