import React, { useState, useEffect } from "react";
import { collection, getDocs } from "@firebase/firestore";
import { db } from "../firebaseConfig/firebase";
import { Link } from "react-router-dom";
import { FaPencilAlt, FaEye  } from "react-icons/fa";
import { RiFileUserFill } from "react-icons/ri";

const Factores = () => {
    const [factores, setFactores] = useState([]);
    const getFactores = async () => {
        const data = await getDocs(collection(db, "FACTORES"));
        const factoresList = data.docs.map(doc => ({ ...doc.data(), id: doc.id}));
        setFactores(factoresList);

    };

    useEffect(() => {
        getFactores(); // Cambiado a "getClientes"
    }, []);
    /*
    const getContactos = async () => {
        const data = await getDocs(collection(db, "CONTACTOS")); // Cambiado a "CLIENTES"
        const contactosList = data.docs.map(doc => ({ ...doc.data(), id: doc.id }));
        setContactos(contactosList);
    }
     */
    return (
        <div className="container">
            <div className="row">
                <div className="col">
                    <div className="d-grid gap-2">
                        <Link to="/agregarFactores" className="btn btn-secondary mt-2 mb-2">Agregar nuevo insumo</Link>
                    </div>
                    <table className="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>CLAVE</th>
                                <th>NOMBRE</th>
                                <th>UTILIDAD</th>
                                <th>COSTO FIJO</th>
                                <th>DETALLE</th>
                                <th>EDITAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            {factores.map((factores) => (
                                <tr>
                                    <td>{factores.cve_far}</td>
                                    <td>{factores.nombre}</td>
                                    <td>{Math.floor(factores.utilidad)}%</td>
                                    <td>{Math.floor(factores.costoFijo)}%</td>
                                    <td><Link to={`/visualizarFactor/${factores.id}`} className="btn btn-light"><FaEye /></Link></td>
                                    <td><Link to={`/editarFactores/${factores.id}`} className="btn btn-light"><FaPencilAlt /></Link></td>
                                </tr>
                            ) )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default Factores