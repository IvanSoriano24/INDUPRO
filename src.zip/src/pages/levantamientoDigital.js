import "bootstrap/dist/css/bootstrap.min.css"
import { useState, useEffect } from "react"
import { db } from "../firebaseConfig/firebase";
import { collection, getDocs, query, where } from "@firebase/firestore";
import {TabContent, TabPane, Nav, NavItem, NavLink  } from "reactstrap"
import { IoSearchSharp } from "react-icons/io5";
import { Link } from "react-router-dom";
import { FaPencilAlt, FaEye  } from "react-icons/fa";
import { RiFileUserFill } from "react-icons/ri";
import { CiCirclePlus } from "react-icons/ci";
const LevantamientoDigital = () => {
    const [activeTab, setActiveTab] = useState("1");

    const cambiarTab = (numeroTab) =>{
        if(activeTab !== numeroTab){
            setActiveTab(numeroTab);
        }
    }

    const [levDigital, setLevDigital] = useState([]);

    const getLevDigital = async () => {
        const levDigitalList = [];
        const levDigitalCollection = collection(db, "LEVDIGITAL");
        const levDigitalSnapshot = await getDocs(levDigitalCollection);

        for (const levDigitalDoc of levDigitalSnapshot.docs) {
          const levDigitalData = levDigitalDoc.data();
          const cveClie = levDigitalData.cve_clie;
        
          // Obtener información del cliente
          const clientesCollection = collection(db, "CLIENTES");
          const clientesQuery = query(clientesCollection, where("cve_clie", "==", cveClie));
          const clientesSnapshot = await getDocs(clientesQuery);
    
          if (!clientesSnapshot.empty) {
            const clienteData = clientesSnapshot.docs[0].data();
            // Combinar información de LEVDIGITAL y CLIENTES
            const combinedData = { ...levDigitalData, cliente: clienteData };
            levDigitalList.push({ ...combinedData, id: levDigitalDoc.id });
          }
        }
    
        setLevDigital(levDigitalList);
      };

    useEffect(() => {
        getLevDigital(); // Cambiado a "getClientes"
    }, []);
    return (
        <div className="panel">
            <div className="row">
                <div className="col-md-10 ">
                    <div className="mb-3">
                        <input
                        placeholder="BUSCAR POR CLAVE" aria-label="" aria-describedby="basic-addon1"
                        type="text"
                        className="form-control"
                        />
                    </div>
                 </div>
                 <div className="col-md-2 ">
                    <div className="mb-3">
                        <div class="input-group-append">
                            <button class="btn btn-outline-secondary" type="button"><IoSearchSharp /></button>
                        </div>
                    </div>
                 </div>
                 <div className="col-md-4 ">
                    <div className="mb-3">
                        <div class="input-group-append">
                            <Link to="/agregarLevDigital"><button class="btn btn-success" type="button"><CiCirclePlus  /> Agregar </button></Link>
                        </div>
                    </div>
                 </div>
            </div>
        <Nav tabs>
            
            <NavItem>
                <NavLink 
                onClick={()=>cambiarTab("1")}
                className={(activeTab=="1" ? "activeTab baseTap": "baseTap")}
                >
                    Hoy
                </NavLink>
            </NavItem>
            <NavItem>
                <NavLink 
                onClick={()=>cambiarTab("2")}
                className={(activeTab=="2" ? "activeTab baseTap": "baseTap")}
                >
                    De este mes
                </NavLink>
            </NavItem>
            <NavItem>
                <NavLink 
                onClick={()=>cambiarTab("3")}
                className={(activeTab=="3" ? "activeTab baseTap": "baseTap")}
                >
                    Mes anterior
                </NavLink>
            </NavItem>
            <NavItem>
                <NavLink 
                onClick={()=>cambiarTab("4")}
                className={(activeTab=="4" ? "activeTab baseTap": "baseTap")}
                >
                    Todas
                </NavLink>
            </NavItem>
        </Nav>
        <TabContent activeTab={activeTab}>
            <TabPane tabId="1">
            <div className="container">
            <div className="row">
                <div className="col">
                    <br/>
                    <table className="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th>FOLIO</th>
                                <th>CLEINTE</th>
                                <th>ESTATUS</th>
                                <th>FECHA</th>
                                <th>DETALLE</th>
                                <th>EDITAR</th>
                            </tr>
                        </thead>
                        <tbody>
                            {levDigital.map((levDigitalItem) => (
                                <tr key={levDigitalItem.id}>
                                    <td>{levDigitalItem.cve_levDig}</td>
                                    <td>{levDigitalItem.cliente.razonSocial}</td>
                                    <td>{levDigitalItem.estatus}</td>
                                    <td>{levDigitalItem.fechaElaboracion}</td>
                                    <td><Link to={`/visualizarContacto/${levDigital.id}`} className="btn btn-light"><FaEye /></Link></td>
                                    <td><Link to={`/editarContacto/${levDigital.id}`} className="btn btn-light"><FaPencilAlt /></Link></td>
                                </tr>
                            ) )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
            </TabPane>

            <TabPane tabId="2">
                <h1>Prueba 2</h1>
            </TabPane>
            <TabPane tabId="3">
                <h1>Prueba 3</h1>
            </TabPane>
            <TabPane tabId="4">
                <h1>Prueba 4</h1>
            </TabPane>
        </TabContent>
    </div>
    )
}

export default LevantamientoDigital